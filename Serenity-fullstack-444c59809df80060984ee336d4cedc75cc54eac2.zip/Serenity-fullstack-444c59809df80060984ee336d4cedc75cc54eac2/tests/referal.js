const anchor = require("@project-serum/anchor");
const { SystemProgram, PublicKey } = anchor.web3;
const assert = require("assert");

describe("referal", () => {
  // Configure the client to use the local cluster.
  const provider = anchor.Provider.env();
  // Configure the client to use the local cluster.
  anchor.setProvider(provider);
  // Program for the tests.
  const program = anchor.workspace.Referal;
  //console.log("program", program);
  // Counter for the tests.
  const referrer = anchor.web3.Keypair.generate();
  const referalCode = "referalCode";

  it("Can create a PDA account with instruction data", async () => {
    const seed = Buffer.from([1, 2, 3, 4]);
    const code = "gpathela";
    //const foo = anchor.web3.SYSVAR_RENT_PUBKEY;
    const [myPda, nonce] = await PublicKey.findProgramAddress(
      [Buffer.from(anchor.utils.bytes.utf8.encode(code)), seed],
      program.programId
    );
    console.log("myPda", myPda.toBase58());
    await program.rpc.codePdaInit(code, seed, nonce, referrer.publicKey, {
      accounts: {
        myPda,
        myPayer: program.provider.wallet.publicKey,
        systemProgram: anchor.web3.SystemProgram.programId,
      },
    });

    const myPdaAccount = await program.account.referrerDetails.fetch(myPda);
    console.log("myPdaAccount", myPdaAccount.referrer.toBase58());
    assert.ok(myPdaAccount.referrer.PublicKey === referrer.PublicKey);
  });

  it("Code exists", async () => {
    const code = "gpathela";
    const seed = Buffer.from([1, 2, 3, 4]);
    const [myPda, nonce] = await PublicKey.findProgramAddress(
      [Buffer.from(anchor.utils.bytes.utf8.encode(code)), seed],
      program.programId
    );
    console.log("myPda", myPda.toBase58());
    try {
      const myPdaAccount = await program.account.referrerDetails.fetch(myPda);
      console.log("myPdaAccount", myPdaAccount.referrer.toBase58());
      await program.rpc.verifyCode(code, seed, nonce, {
        accounts: {
          myPda,
          myPayer: program.provider.wallet.publicKey,
          systemProgram: anchor.web3.SystemProgram.programId,
        },
      });
      assert.ok(true);
    } catch (e) {
      console.log("e", e);
      assert.ok(false);
    }
  });

  it("Code not exists - verification at Frontend", async () => {
    const code = "gpathela1";
    const seed = Buffer.from([1, 2, 3, 4]);
    const [myPda, nonce] = await PublicKey.findProgramAddress(
      [Buffer.from(anchor.utils.bytes.utf8.encode(code)), seed],
      program.programId
    );
    console.log("myPda", myPda.toBase58());
    try {
      const myPdaAccount = await program.account.referrerDetails.fetch(myPda);
      console.log("myPdaAccount", myPdaAccount.referrer.toBase58());
      assert.ok(false);
    } catch (e) {
      console.log("e", e);
      assert.ok(true);
    }
  });

  it("Code not exists - verification at Blockchain", async () => {
    const code = "gpathela1";
    const seed = Buffer.from([1, 2, 3, 4]);
    const [myPda, nonce] = await PublicKey.findProgramAddress(
      [Buffer.from(anchor.utils.bytes.utf8.encode(code)), seed],
      program.programId
    );
    console.log("myPda", myPda.toBase58());
    try {
      await program.rpc.verifyCode(code, seed, nonce, {
        accounts: {
          myPda,
          myPayer: program.provider.wallet.publicKey,
          systemProgram: anchor.web3.SystemProgram.programId,
        },
      });
      assert.ok(false);
    } catch (e) {
      console.log("e", e);
      assert.ok(true);
    }
  });
});
