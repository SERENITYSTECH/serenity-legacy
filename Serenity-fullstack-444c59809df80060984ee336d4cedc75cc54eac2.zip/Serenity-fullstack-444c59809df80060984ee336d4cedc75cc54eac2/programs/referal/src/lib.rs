use anchor_lang::prelude::*;
use std::convert::Into;

declare_id!("CoFW2Rtehb4B9g5msJgsPZxudTZpwEQjtoSuqZqtberx");

#[program]
pub mod referal {
    use super::*;

    pub fn code_pda_init(
        ctx: Context<CodePdaInit>,
        _code: String,
        _seed: Vec<u8>,
        _bump: u8,
        referrer: Pubkey,
    ) -> ProgramResult {
        ctx.accounts.my_pda.referrer = referrer;
        Ok(())
    }

    pub fn verify_code(
        ctx: Context<VerifyCode>,
        code: String,
        seed: Vec<u8>,
        _bump: u8,
    ) -> ProgramResult {
        let (pda, _bump_seed) =
            Pubkey::find_program_address(&[code.as_bytes(), &seed], ctx.program_id);
        msg!("pda: {:?}", pda);
        Ok(())
    }
}

#[derive(Accounts)]
#[instruction(code: String, seed: Vec<u8>, bump: u8)]
pub struct CodePdaInit<'info> {
    #[account(
        init,
        seeds = [code.as_bytes(), &seed],
        bump = bump,
        payer = my_payer,
    )]
    my_pda: ProgramAccount<'info, ReferrerDetails>,
    my_payer: AccountInfo<'info>,
    system_program: AccountInfo<'info>,
}

#[derive(Accounts)]
pub struct VerifyCode<'info> {
    my_pda: ProgramAccount<'info, ReferrerDetails>,
    my_payer: AccountInfo<'info>,
    system_program: AccountInfo<'info>,
}

#[account]
#[derive(Default)]
pub struct ReferrerDetails {
    referrer: Pubkey,
}
